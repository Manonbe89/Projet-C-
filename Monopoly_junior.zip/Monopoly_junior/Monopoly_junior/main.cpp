#include <string>
#include <iostream>
#include <vector>

#include "Monopoly.h"
#include "Player.h"
#include "Board.h"
int main(void) {
	
	return 0;
}