#pragma once
#include <string>
#include <iostream>
class Board
{

};